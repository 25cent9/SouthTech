﻿/*
 * Innocent Niyibizi
 * 12/1/15
 * Create program to test write commands
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace exerciseSix{
    class Program{
        static void Main(string[] args){
            Console.Write("Shrek is love");
            Console.Write(", Shrek is life");
            Console.Write(", All hail Shrek");
            Console.Write("\n\n\n");
            Console.Write("Shrek is love,\nShrek is life,\nAll hail Shrek\n\n\n");
            Console.Write("Shrek \nis \nlove,\nShrek \nis \nlife,\nAll \nhail \nShrek\n\n\n");

            Console.Read();
        }
    }
}
