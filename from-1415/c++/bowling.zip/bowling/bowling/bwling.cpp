/*
	Programmer: Innocent
	Date: 5-11-15
	Purpose: To create a program to calculate the points in a session of bowling
*/

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
int calcTotalStrike(int, int, int);
int calcTotalSpare(int, int);
int main(){
	int total = 0;
	int frameTotal = 0;
	int frame_first = 0;
	int frame_second = 0;
	char choice = ' ';
	int totals[10] = {};
	int numStrike = 0;
	int numSpare = 0;
	int numOpen = 0;
	do{	//Loop to run one time and then ask the user if they want to contiue by entering y
		for(int x=0; x<10; x++){	//Loop to run until it reaches the 10th frame

			int framePoints[2]={};	//Array to hold the values of the two balls
			cout<<"Please enter the first ball for frame "<<x+1<<" : ";
			cin>>framePoints[0];
			if(framePoints[0]!=10){
				cout<<"Please enter the second ball for frame "<<x+1<<" : ";
				cin>>framePoints[1];
			}
			if(x==9){
				
			}
			while(framePoints[0]+framePoints[1]>10){	//Loop to run if the rolls are highrt 
				cout<<"Error: The values you entered are over 10, please reenter."<<endl;
				cout<<"Please enter the first ball for frame "<<x+1<<" : ";
				cin>>framePoints[0];
				if(framePoints[0]!=10){
					cout<<"Please enter the second ball for frame "<<x+1<<" : ";
					cin>>framePoints[1];
				}
			}

			frameTotal = framePoints[0]+framePoints[1];	//Calculating the total points earned in the frame
			
			if(framePoints[0]==10){
				do{
					frameTotal=10;
					x++;
					cout<<"Please enter the first ball for frame "<<x+1<<" : ";
					cin>>framePoints[0];
					if(framePoints[0]!=10){
						cout<<"Please enter the second ball for frame "<<x+1<<" : ";
						cin>>framePoints[1];
					}
					frame_first=framePoints[0];	//Setting the values to a seperate variable for future scoring purposes
					frame_second=framePoints[1];
					total += calcTotalStrike(10, frame_first, frame_second);
					numStrike++;
				}while(framePoints[0]==10);
			}
			else if(frameTotal==10){
				do{
					frameTotal=10;
					x++;
					cout<<"Please enter the first ball for frame "<<x+1<<" : ";
					cin>>framePoints[0];
					if(framePoints[0]!=10){
						cout<<"Please enter the second ball for frame "<<x+1<<" : ";
						cin>>framePoints[1];
					}
					frame_first=framePoints[0];	//Setting the values to a seperate variable for future scoring purposes
					frame_second=framePoints[1];
					total += calcTotalSpare(10, frame_first);
					numSpare++;
				}while(frameTotal==10);
			}

			else{
				frame_first=framePoints[0];	//Setting the values to a seperate variable for future scoring purposes
				frame_second=framePoints[1];
				total += frameTotal;
				numOpen++;
			}
		}
		
	}while(choice=='y');
	cout<<"Frame"<<setw(5)<<"Score"<<endl;
	cout<<"------"<<setw(5)<<"------"<<endl;
	for(int z=0; z<10; z++){
		cout<<z+1<<stew(5)<<totals[z]<<endl;
	}
	cout<<"Number of strikes : "<<numStrike<<endl;
	cout<<"Number of spares : "<<numSpare<<endl;
	cout<<"Open frames : "<<numOpen<<endl;

	system("pause");
	return 0;
}

int calcTotalStrike(int strike, int first, int second){
	return strike+(first+second);
}
int calcTotalSpare(int spare, int first){
	return spare+first;
}
