﻿/*  Innocent Niyibizi
 *  12/1/15
 *  Create program to spell out C#
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace chapter1_Exp2{
    class Program{
        static void Main(string[] args){
            Console.Write("CCCCCCCCCCC\t\t\t\t\n");
            Console.Write("CC\t\t\t\t\t##   ##\n");
            Console.Write("CC\t\t\t\t\t#######\n");
            Console.Write("CC\t\t\t\t\t##   ##\n");
            Console.Write("CC\t\t\t\t\t#######\n");
            Console.Write("CC\t\t\t\t\t##   ##\n");
            Console.Write("CCCCCCCCCCC\t\t\t\t\n");
            Console.ReadLine();
        }
    }
}
