﻿/*
 * Innocent Niyibizi
 * 12/1/15
 * Create a program that produces a banner and a flag 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fourAndFive{
    class Program{
        static void Main(string[] args){
            /*
            Console.Write("**************************************************\n");
            Console.Write("**\tProgrammingg Assignment #4\t\t**\n");
            Console.Write("**\tDeveloper: Innocent Niyibizi\t\t**\n");
            Console.Write("**\tDate Submitted: December 1\t\t**\n");
            Console.Write("**\tPurpose: Provide internal documentation\t**\n");
            Console.Write("**************************************************\n\n");
            */
            Console.Write("* * * * * *■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write(" * * * * * ■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("* * * * * *■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write(" * * * * * ■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("* * * * * *■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write(" * * * * * ■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("* * * * * *■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
            Console.Write("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");

            Console.Read();
        }
    }
}
